//
//  ImageUtils.h
//  CUELiveBundle
//
//  Created by Jameson Rader on 7/19/18.
//  Copyright © 2018 CUE Audio. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class UIImage, SelfieCam, LightShow, TriviaGame;

static NSString* TriviaDidCompleteNotification = @"triviaGameDidComplete";

@interface CUELightShowUtils : NSObject

+ (void) getImageWithURL: (NSString *) urlString andCompletionHandler:(void (^)(UIImage * image))completion;
+ (void) saveImage: (UIImage *) image atPath: (NSString *) imagePath;
+ (BOOL) doesFileExist: (NSString *) path;
+ (NSString *) createPathFromName: (NSString *) imgName;
+ (void) saveNSData: (NSData *) data atPath: (NSString *) path;
+ (UIImage *) retrieveImageFromMemory: (NSString *) imagePath;
+ (UIImage *) retrieveGIFFromMemory: (NSString *) path;
+ (void) downloadImage: (NSURL *) url withCompletionHandler:(void (^)(UIImage * image))completion;
+ (BOOL) checkIfURLIsValidLSImageType: (NSString *) urlString;
+ (BOOL) checkIfURLIsValidSelfieCamImageType: (NSString *) urlString;
+ (void) getNSDataWithURL: (NSString *) urlString andCompletionHandler:(void (^)(NSData * downloadedData))completion;
+ (BOOL) checkIfURLIsGIF: (NSString *) urlString;
+ (BOOL) checkIfURLIsJPG: (NSString *) urlString;
+ (BOOL) checkIfURLIsPNG: (NSString *) urlString;
+ (BOOL) checkIfURLIsMP3: (NSString *) urlString;

//SC
+ (UIImage*)imageByCombiningImage:(UIImage*)firstImage withImage:(UIImage*)secondImage;
+ (UIImage*) scaleImage:(UIImage*)image toSize:(CGSize)newSize;
+ (UIImage *)imageWithImage:(UIImage *)image convertToSize:(CGSize)size;

+ (NSString *) getAppName;

////services
//+ (NSDictionary *) getLightShowsFromJSON: (NSArray *) jsonArray;
//+ (NSDictionary *) getSelfieCamsFromJSON: (NSArray *) jsonArray;
//+ (NSDictionary *) getTriviaGamesFromJSON: (NSArray *) jsonArray;
//+ (NSDictionary *) getLiveModeLightShowsFromJSON: (NSArray *) jsonArray;

//+ (LightShow *) getLightShowWithTrigger: (NSString *) triggerString;
//+ (SelfieCam *) getSelfieCamWithTrigger: (NSString *) triggerString;
//+ (TriviaGame *) getTriviaGameWithTrigger: (NSString *) triggerString;

@end
