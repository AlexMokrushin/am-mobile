//
//  MultiDownloader.h
//  MultiDownloader
//
//  Created by Jameson Rader on 7/21/18.
//  Copyright © 2018 CUE Audio, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CUEMultiDownloader : NSObject

+ (void) fetchCUETheme;
+ (void) fetchCUETheme: (NSString *) apiKey;
+ (void) getLiveEventJSONWithCompletionHandler: (void (^)(NSData* data)) completionHandler withApiKey: (NSString *) apiKey;
+ (void) getLiveEventJSONWithCompletionHandler: (void (^)(NSData* data)) completionHandler;
+ (void) fetchCUEThemeWithCompletionHandler: (void (^)(BOOL dataIsNew))completionHandler;
+ (instancetype) sharedInstance;
- (void)feedURLArray: (NSArray *) urls;
- (void) replaceURLArray: (NSArray *) urls withCompletionHandler:(void (^)(void))completion;

@end
