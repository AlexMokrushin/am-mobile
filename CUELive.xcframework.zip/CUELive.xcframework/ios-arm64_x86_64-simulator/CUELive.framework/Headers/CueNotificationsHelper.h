//
//  CueNotificationsHelper.h
//  CUELive
//
//  Created by Jameson Rader on 10/15/19.
//  Copyright © 2019 CUE Audio. All rights reserved.
//

#import <Foundation/Foundation.h>

@class UNNotificationResponse;

NS_ASSUME_NONNULL_BEGIN

@interface CueNotificationsHelper : NSObject

+ (instancetype) sharedInstance;
- (void) handleNotificationResponse:(UNNotificationResponse *)response withPresentingViewController:(UIViewController *) viewController;
- (void) handleDetectedBleTrigger: (NSString *) symbolString;
- (void) sendNotificationInBackground:(NSString *) title withSubtitle: (NSString *) subtitle andBody: (NSString *) body forSymbolString: (NSString *) symbolString;

@end

NS_ASSUME_NONNULL_END
