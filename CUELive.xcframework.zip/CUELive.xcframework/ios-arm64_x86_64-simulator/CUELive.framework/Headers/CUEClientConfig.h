//
//  ClientConfig.h
//  LightShowLib
//
//  Created by CUE Audio on 19/10/2018.
//  Copyright © 2018 CUE Audio. All rights reserved.
//

#import <Foundation/Foundation.h>

@class UIColor;

NS_ASSUME_NONNULL_BEGIN

@interface CUEClientConfig : NSObject

+ (NSDictionary *) getConfigPlistAsDictionary;

+ (instancetype) sharedInstance;

- (NSString*) clientId;
- (NSString*) primaryColorString;
- (UIColor *) generalTextColor;
- (NSString*) preferredFont;
- (NSString* _Nullable) appLanguage;
- (BOOL) hasExit;
- (BOOL) hasExitOnHomescreen;
- (BOOL) shouldHideMenu;
- (BOOL) shouldShowNotificationOnboarding;
- (BOOL) shouldShowInfoOnboarding;
- (BOOL) usesCueBroadcastClient;
- (NSString *) cueBroadcastServiceUuid;
- (BOOL) usesMicrophone;
- (BOOL) usesMqtt;
- (NSArray *) customMenuCells;
- (NSString *_Nullable)appName;

@end

NS_ASSUME_NONNULL_END
