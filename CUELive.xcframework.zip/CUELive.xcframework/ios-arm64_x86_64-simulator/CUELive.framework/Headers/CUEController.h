//
//  CUEController.h
//  Light Show
//
//  Created by Jameson Rader on 3/30/18.
//  Copyright © 2018 CUE Audio, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

#import "LSConfig.h"

FOUNDATION_EXPORT const NSNotificationName kJSONFileSavedNotification;
FOUNDATION_EXPORT const NSNotificationName kLightShowStarted;
FOUNDATION_EXPORT const NSNotificationName kServiceDisplayed;
FOUNDATION_EXPORT const NSNotificationName kServiceDisplayStopped;

@class CUESelfieCamViewController, SelfieCam, LightShow, TriviaGame, UPN;

typedef NS_ENUM(NSInteger, CUEEventType) {
    //Light Show
    CUEEventTypeLightShow = 0,
    //Selfie Cam
    CUEEventTypeSelfieCam = 1,
    //Trivia
    CUEEventTypeTrivia = 2,
    //TriviaTimeout
    CUEEventTypeTriviaTimeout = 3,
    //UPN
    CUEEventTypeUPN = 4,
    //Parsing failure
    CUEEventTypeParsingFailure = 5,
    //NTP failure
    CUEEventTypeNtpFailure = 6,
    //MQTT Subscribe failure
    CUEEventTypeMqttSubscribeFailure = 7,
    //MQTT Subscribe failure FINAL
    CUEEventTypeMqttSubscribeFailureFinal = 8,
};

typedef NS_ENUM(NSInteger, CUEParameterType) {
    CUEParameterTypeTrigger = 0,
    CUEParameterTypeTriviaGameID = 1,
    CUEParameterTypeErrorMessage = 2,
};

extern NSNotificationName CUEParsingErrorNotificationName;
extern NSNotificationName CUENtpErrorNotificationName;
extern NSNotificationName CUEMqttErrorNotificationName;
extern NSNotificationName CUEMqttFinalErrorNotificationName;

@protocol CUEControllerHandlerDelegate <NSObject>
- (BOOL) shouldTakeoverFor: (CUEEventType) cueEvent;
- (UIViewController *) getPresentingViewController;
@end

@protocol CUEControllerLiveDelegate <NSObject>
- (BOOL) shouldInitiateLightShow: (LightShow *) lightShow;
- (BOOL) shouldInitiateSelfieCam: (SelfieCam *) selfieCam;
- (BOOL) shouldInitiateTriviaGame: (TriviaGame *) game;
- (BOOL) shouldInitiateUPN: (UPN *) upn;
@optional
- (void) didStartLightShow: (LightShow *) lightShow;
- (void) didEndLightShow: (LightShow *) lightShow;
- (void) didExtractLSJSON: (NSData *) json fromDisk: (BOOL) fromDisk;
- (void) didStartSelfieCam;
- (void) didEndSelfieCam;
- (void) didStartTriviaGame;
- (void) didEndTriviaGame;
- (void) didStartUPN;
- (void) didEndUPN;
@end


@protocol CUEControllerTriggerTracker <NSObject>
- (void) didHearTrigger: (NSString *) triggerString;
@optional
- (void) didHearMqttTrigger: (NSString *) triggerString;
- (void) didHearBleTrigger: (NSString *) triggerString;
- (void) didInitiateEventType: (CUEEventType) eventType withParameterType: (CUEParameterType) paramType withParameterValue: (NSString *) value withDemo: (BOOL) demo;
@end

typedef NS_ENUM(NSInteger, CUEClearingReason) {
    CUEClearingReasonDidEnterBackground,
    CUEClearingReasonNewScreen,
    CUEClearingReasonExitApp,
};

@interface CUEController : NSObject

//delegates
@property (weak, nonatomic) id<CUEControllerLiveDelegate> delegate;
@property (weak, nonatomic) id<CUEControllerHandlerDelegate> handlerDelegate;
@property (weak, nonatomic) id<CUEControllerTriggerTracker> trackerDelegate;

//light show fundamentals
@property NSMutableArray *currentLightShows;
@property (weak, nonatomic) UIImageView *lightShowImageView;
@property UIView *colorView;
@property BOOL respondToEngine;

//camera
@property float cameraTimerFrequency;
@property NSString *camTimerLabelText;

//Emit sound effects
@property AVAudioPlayer *player;

//sections
@property (nonatomic, strong) NSArray *sections;
@property NSString *selectedSection;

//public methods
- (void) clearAll:(CUEClearingReason)reason;
- (void) setLightShowRunning:(BOOL)lightShowRunning;
- (BOOL) tryStartListening;
+ (instancetype) sharedInstance;
- (void) extractProductObjsFromJSON: (NSData *) json fromDisk: (BOOL) fromDisk;
+ (int) getBitDifferenceBetween: (NSString *) tone1 and: (NSString *) tone2;

//tracking
- (void) triviaDidTimeoutRetreivingRank: (NSString *) gameID;

//alerts
+ (UIAlertController *) createAlert: (CUEAlertType) type withSuccessHandler:(void (^)(UIAlertAction *action))successHandler andFailureHandler:(void (^)(UIAlertAction *action))failureHandler;

//vibration (compatible with ultrasonic engine)
- (void) vibrate;

//emit audio
- (void) echo: (NSString *) path andVolume: (float) vol andLoop: (BOOL) loop;
- (void) stopSoundEffect;

@end
